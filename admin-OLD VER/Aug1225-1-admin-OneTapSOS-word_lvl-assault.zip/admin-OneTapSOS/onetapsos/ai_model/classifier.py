import joblib
import os
import json
import re

# Paths
BASE_DIR = os.path.dirname(__file__)
WORD_LVL_DIR = os.path.join(BASE_DIR, "word_lvl")

# Load the trained model (TF-IDF + Naive Bayes)
model_path = os.path.join(BASE_DIR, "emergency_classifier.pkl")
model = joblib.load(model_path)

# Load keyword-based boosting dictionary (still stores which keywords belong to each category)
keywords_path = os.path.join(BASE_DIR, "keyword_boost.json")
with open(keywords_path, 'r', encoding='utf-8') as f:
    keyword_dict = json.load(f)

# Load normalization dictionary
normalization_path = os.path.join(BASE_DIR, "word_normalization.json")
with open(normalization_path, 'r', encoding='utf-8') as f:
    normalization_dict = json.load(f)

# Compile regex patterns for normalization
substitution_patterns = {
    re.compile(r'\b(' + '|'.join(map(re.escape, variants)) + r')\b'): root
    for root, variants in normalization_dict.items()
}

def normalize_text(text):
    """Replace word variants with their normalized root forms."""
    text = text.lower()
    for pattern, replacement in substitution_patterns.items():
        text = pattern.sub(replacement, text)
    return text

def load_word_weights(category):
    """Load per-category word weight JSON file."""
    filepath = os.path.join(WORD_LVL_DIR, f"{category}_word.json")
    if os.path.exists(filepath):
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}  # No weights → all words get default 1.0

def keyword_boost_levels(text):
    """
    Keyword boosting that combines:
    - Keyword level from keyword_boost.json
    - Word weight level from word_lvl/{category}_word.json
    Returns: dict {label: total score}
    """
    text = text.lower()
    score_dict = {}

    for label, keywords in keyword_dict.items():
        # Load category-specific word weight levels
        word_weights = load_word_weights(label)
        score = 0.0

        for entry in keywords:
            *keyword_parts, level_str = entry.rsplit(" ", 1)
            keyword = " ".join(keyword_parts)
            try:
                keyword_level = int(level_str)
            except ValueError:
                continue

            if re.search(r'\b' + re.escape(keyword) + r'\b', text):
                # Get word weight level (default 1.0 if not listed)
                word_weight = word_weights.get(keyword, 1.0)
                # Multiply keyword level by word weight
                score += keyword_level * word_weight

        if score > 0:
            score_dict[label] = score

    return score_dict

def classify_emergency(text):
    """
    Classify text and apply keyword boosting.
    Returns: (label, confidence %)
    """
    normalized_text = normalize_text(text)

    # Model prediction
    prediction_proba = model.predict_proba([text])[0]
    predicted_label = model.classes_[prediction_proba.argmax()]
    confidence = round(prediction_proba.max() * 100, 2)

    # Keyword boosting
    match_scores = keyword_boost_levels(normalized_text)

    # Debug info
    print(f"[DEBUG] Raw Text: {text}")
    print(f"[DEBUG] Normalized: {normalized_text}")
    print(f"[DEBUG] Prediction Probabilities: {dict(zip(model.classes_, prediction_proba))}")
    print(f"[DEBUG] Keyword Match Scores: {match_scores}")
    print(f"[DEBUG] Initial Prediction: {predicted_label} ({confidence}%)")

    if match_scores:
        top_keyword_label = max(match_scores, key=match_scores.get)
        top_keyword_score = match_scores[top_keyword_label]

        if top_keyword_label == predicted_label:
            confidence = min(confidence + top_keyword_score * 7, 100.0)
        else:
            alt_index = list(model.classes_).index(top_keyword_label)
            alt_conf = prediction_proba[alt_index] * 100 + top_keyword_score * 7
            if alt_conf > confidence:
                predicted_label = top_keyword_label
                confidence = round(min(alt_conf, 100.0), 2)

    return predicted_label, confidence

# Optional test run
if __name__ == "__main__":
    test_text = input("Input your emergency here: ")
    label, confidence = classify_emergency(test_text)
    print(f"Test: {test_text}")
    print(f"Prediction: {label} ({confidence}%)")
