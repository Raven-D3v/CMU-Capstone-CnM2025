import joblib
import os
import json
import re

# Load the trained model (TF-IDF + Naive Bayes)
model_path = os.path.join(os.path.dirname(__file__), "emergency_classifier.pkl")
model_data = joblib.load(model_path)
model = joblib.load(model_path)

# Load keyword-based boosting dictionary
keywords_path = os.path.join(os.path.dirname(__file__), "keyword_boost.json")
with open(keywords_path, 'r', encoding='utf-8') as f:
    keyword_dict = json.load(f)

def keyword_boost(text):
    """
    Checks text for class-based keywords. Returns matched classes.
    """
    text = text.lower()
    matches = []

    for label, keywords in keyword_dict.items():
        for keyword in keywords:
            if re.search(r'\b' + re.escape(keyword) + r'\b', text):
                matches.append(label)
    return matches

def classify_emergency(text):
    """
    Returns:
        label (str): predicted category
        confidence (float): confidence percentage (0–100)
    """
    prediction_proba = model.predict_proba([text])[0]
    predicted_label = model.classes_[prediction_proba.argmax()]
    confidence = round(prediction_proba.max() * 100, 2)

    matches = keyword_boost(text)

    if matches:
        if predicted_label in matches:
            confidence = min(confidence + 10, 100.0)
        else:
            for label in matches:
                if label != predicted_label:
                    index = list(model.classes_).index(label)
                    alt_conf = prediction_proba[index] * 100 + 10
                    if alt_conf > confidence:
                        predicted_label = label
                        confidence = round(min(alt_conf, 100.0), 2)
                        break

    return predicted_label, confidence

# Optional test run
if __name__ == "__main__":
    test_text = "Nasaksak ako"
    label, confidence = classify_emergency(test_text)
    print(f"Test: {test_text}")
    print(f"Prediction: {label} ({confidence}%)")
