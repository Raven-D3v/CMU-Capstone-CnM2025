import joblib
import os

# Load the trained model
model_path = os.path.join(os.path.dirname(__file__), "emergency_classifier.pkl")
model = joblib.load(model_path)

def classify_emergency(text):
    """
    Returns:
        label (str): predicted category
        confidence (float): confidence percentage (0–100)
    """
    prediction = model.predict([text])[0]
    probabilities = model.predict_proba([text])[0]
    confidence = max(probabilities) * 100  # Convert to percentage
    return prediction, round(confidence, 2)  # e.g., ("robbery", 92.36)

# Optional test
if __name__ == "__main__":
    test_text = "I have been robbed." #text input for testing
    label, confidence = classify_emergency(test_text)
    print(f"test_text: {test_text}")
    print(f"Prediction: {label} ({confidence}%)")
